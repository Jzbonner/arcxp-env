import React from 'react';

const BreakingNews = () => <div className="b-placeholder c-breakingNews">Breaking News</div>;

export default BreakingNews;
