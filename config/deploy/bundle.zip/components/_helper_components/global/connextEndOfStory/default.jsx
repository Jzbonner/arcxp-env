import React from 'react';
import './default.scss';

const ConnextEndOfStory = () => <p className="c-connext eos-msg__nolog-or-nosub b-margin-bottom-d40-m20">APD-21</p>;

export default ConnextEndOfStory;
