import React from 'react';
import './styles.scss';

const Divider = () => (
  <>
    <hr className="divider"/>
  </>
);

export default Divider;
