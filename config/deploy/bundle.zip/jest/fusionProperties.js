const properties = require('../properties/index.json');

module.exports = () => properties;
