export default {
  defaultSiteTitle: 'AJC',
  dfpId: '21849707860',
  siteDomainURL: '//www.ajc.com',
  twitterURL: '//twitter.com/ajc',
  facebookURL: '//facebook.com/ajc',
  instagramURL: '//instagram.com/ajcnews',
};
