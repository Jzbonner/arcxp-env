# Resources

Any public, static resources should be placed here. All files in this directory will be stored in and served by S3 from `/pf/resources/...`.
