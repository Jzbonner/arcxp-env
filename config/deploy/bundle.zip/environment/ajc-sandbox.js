export default {
  connext: {
    isEnabled: true,
    clientCode: 'ajc',
    environment: 'stage',
    siteCode: 'AJC',
    configCode: 'AJC_STAGE_DEFAULT',
    debug: false,
    tagManager: 'GTM',
    containerId: 'GTM-W3VLHBK',
  },
};
