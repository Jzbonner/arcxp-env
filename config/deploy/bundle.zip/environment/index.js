/* eslint-disable max-len */
module.exports = {
  RESIZER_SECRET_KEY: 'Fmkgru2rZ2uPZ5wXs7B2HbVDHS2SZuA7',
  taboolaID: {
    boapPTD: `[1110597, 1099013, // ajc qa/prod
    ]`,
    moapPTD: `[1110596, 1099909, // ajc qa/prod
    ]`,
  },
  fbPagesId: '13310147298', // ajc
  connext: {
    isEnabled: true,
    clientCode: 'ajc',
    environment: 'stage',
    siteCode: 'AJC',
    configCode: 'AJC_STAGE_DEFAULT',
    debug: true,
    tagManager: 'GTM',
    containerId: 'GTM-W3VLHBK',
  },
};
