export default {
  connext: {
    isEnabled: true,
    clientCode: 'ajc',
    environment: 'prod',
    siteCode: 'AJC',
    configCode: 'AJC_PROD_DEFAULT',
    debug: false,
    tagManager: 'GTM',
    containerId: 'GTM-W3VLHBK',
  },
};
